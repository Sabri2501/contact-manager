export default function Index() {
    return (
      <p>
        Welcome to the React Router tutorial. Start by creating your first contact!
      </p>
    );
  }
  